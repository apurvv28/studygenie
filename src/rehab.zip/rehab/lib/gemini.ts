import { GoogleGenerativeAI } from "@google/generative-ai";

interface ConsultationResponse {
  message: string;
}

// Function to generate a consultation response using Gemini API
export async function generateConsultation(
  doctorGender: 'male' | 'female',
  messages: any[],
  inputMessage: string
): Promise<ConsultationResponse> {
  try {
    // Initialize the Gemini API with the API key from environment variables
    const API_KEY = "AIzaSyC-eiFWed8-RzTqSwTOyclYOxHr4M4gbq8";
    
    // Check if API key is valid
    if (!API_KEY || API_KEY === "AIzaSyC-eiFWed8-RzTqSwTOyclYOxHr4M4gbq8") {
      throw new Error('Invalid API key');
    }
    
    const genAI = new GoogleGenerativeAI(API_KEY);

    // Create a conversation history context for the model
    const conversationHistory = messages.map(msg => 
      `${msg.sender === 'user' ? 'User' : 'Psychiatrist'}: ${msg.text}`
    ).join('\n');
    
    // Create a prompt for the model
    const prompt = `
      You are a professional, empathetic psychiatrist named Dr. ${doctorGender === 'male' ? 'Prerna' : 'Vishwas'}.
      
      Previous conversation:
      ${conversationHistory}
      
      User's latest message: "${inputMessage}"
      
      Respond as a psychiatrist with a helpful, empathetic, and professional response. 
      Keep your response concise (maximum 3-4 sentences) and focused on the user's concerns.
      Provide practical advice when appropriate, but avoid making definitive diagnoses.
      If the user mentions feeling severely depressed or having thoughts of self-harm, 
      encourage them to seek immediate professional help.
    `;

    // Generate a response using the Gemini model
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });
    const result = await model.generateContent(prompt);
    const response = result.response.text();
    
    return { message: response };
  } catch (error) {
    console.error("Error generating consultation with Gemini:", error);
    
    // Fallback responses in case the API fails
    const fallbackResponses = [
      "I understand how you're feeling. Let's work through this together. What specific aspects of this issue are most challenging for you?",
      "Thank you for sharing that with me. It takes courage to discuss these feelings. Would you like to explore some coping strategies that might help?",
      "I hear your concerns. Many people experience similar challenges, and there are effective ways to address them. Shall we discuss some approaches that might work for you?",
      "That's important information for us to work with. Could you tell me more about how this has been affecting your daily life?"
    ];
    
    const randomIndex = Math.floor(Math.random() * fallbackResponses.length);
    return { message: fallbackResponses[randomIndex] };
  }
}