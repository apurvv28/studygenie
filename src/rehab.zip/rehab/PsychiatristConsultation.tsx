import React, { useState, useEffect, useRef } from 'react';
import { Player } from '@lottiefiles/react-lottie-player';
import Webcam from 'react-webcam';
import SpeechRecognition, { useSpeechRecognition } from 'react-speech-recognition';
import { Mic, MicOff, Send, Volume2, Edit2, Check, User, Home, Download, PieChart, Brain } from 'lucide-react';
import { jsPDF } from 'jspdf';
import { generateConsultation } from './lib/gemini';
import { Pie } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import '../styles/PsychiatristConsultation.css';
import { useNavigate } from 'react-router-dom';
// Register Chart.js components
ChartJS.register(ArcElement, Tooltip, Legend);

const maleVideoPath = new URL('/src/rehab/male.mp4', import.meta.url).href;
const femaleVideoPath = new URL('/src/rehab/female1.mp4', import.meta.url).href;
const docimgpath = new URL('/src/rehab/male1.png', import.meta.url).href;

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'psychiatrist';
  timestamp: Date;
}

interface CopingStrategy {
  strategy: string;
  effectiveness: number;
}

interface StressData {
  label: string;
  value: number;
  color: string;
}

export default function PsychiatristConsultation() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isThinking, setIsThinking] = useState(false);
  const [doctorGender, setDoctorGender] = useState<'male' | 'female'>('male');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentAIResponse, setCurrentAIResponse] = useState<string>('');
  const [useVideo, setUseVideo] = useState(false);
  const [showExportDialog, setShowExportDialog] = useState(false);
  const navigate = useNavigate();
  const consultantGender = doctorGender;
  // Stress level data for pie chart
  const [stressData, setStressData] = useState({
    labels: ['Work Stress', 'Family Stress', 'Financial Stress', 'Health Stress', 'Social Stress'],
    datasets: [
      {
        data: [35, 20, 15, 10, 20],
        backgroundColor: [
          'rgba(255, 99, 132, 0.7)',
          'rgba(54, 162, 235, 0.7)',
          'rgba(255, 206, 86, 0.7)',
          'rgba(75, 192, 192, 0.7)',
          'rgba(153, 102, 255, 0.7)',
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(153, 102, 255, 1)',
        ],
        borderWidth: 1,
      },
    ],
  });
  
  const [copingStrategies, setCopingStrategies] = useState<CopingStrategy[]>([
    { strategy: 'Deep Breathing', effectiveness: 75 },
    { strategy: 'Mindfulness', effectiveness: 65 },
    { strategy: 'Physical Exercise', effectiveness: 80 },
    { strategy: 'Journaling', effectiveness: 60 },
    { strategy: 'Social Support', effectiveness: 70 }
  ]);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const webcamRef = useRef<Webcam>(null);
  const speechSynthesis = window.speechSynthesis;
  const videoRef = useRef<HTMLVideoElement>(null);

  const {
    transcript,
    listening,
    resetTranscript,
    browserSupportsSpeechRecognition
  } = useSpeechRecognition();

  useEffect(() => {
    const loadVoices = () => {
      const voices = speechSynthesis.getVoices();
      if (voices.length > 0) {
        const initialMessage: Message = {
          id: Date.now().toString(),
          text: `Hello, I'm Dr. ${doctorGender === 'male' ? 'Vishwas' : 'Prerna'}. I'm here to help with any mental health concerns you might have. How are you feeling today?`,
          sender: 'psychiatrist',
          timestamp: new Date()
        };

        setMessages([initialMessage]);
        setCurrentAIResponse(initialMessage.text);
        speakMessage(initialMessage.text);
      }
    };

    speechSynthesis.onvoiceschanged = loadVoices;
    loadVoices();

    return () => {
      speechSynthesis.cancel();
    };
  }, [doctorGender]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (transcript && !isEditing) {
      setInputMessage(transcript);
    }
  }, [transcript, isEditing]);

  const speakMessage = (text: string) => {
    if ('speechSynthesis' in window) {
      speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
  
      const selectVoice = () => {
        const voices = speechSynthesis.getVoices();
        
        let preferredVoices = voices.filter(voice => {
          const voiceName = voice.name.toLowerCase();
          return doctorGender === 'male'
            ? voiceName.includes('david') || voiceName.includes('alex') || voiceName.includes('daniel') || voiceName.includes('male') 
            : voiceName.includes('samantha') || voiceName.includes('victoria') || voiceName.includes('female') || voiceName.includes('woman');
        });
  
        // Fallback: Choose any available male/female voice if no specific match found
        if (preferredVoices.length === 0) {
          preferredVoices = voices.filter(voice => voice.name.toLowerCase().includes(doctorGender));
        }
  
        // Final fallback: Pick the first available voice
        utterance.voice = preferredVoices[0] || voices[0];
  
        // Adjust pitch to make male voice deeper and female voice slightly higher
        utterance.pitch = doctorGender === 'female' ? 1.2 : 0.9;
      };
  
      // If voices are already loaded, select voice immediately
      if (speechSynthesis.getVoices().length > 0) {
        selectVoice();
        speechSynthesis.speak(utterance);
      } else {
        // Wait for voices to be available
        speechSynthesis.addEventListener('voiceschanged', () => {
          selectVoice();
          speechSynthesis.speak(utterance);
        });
      }
  
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
    }
  };
  

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const toggleMic = () => {
    if (listening) {
      SpeechRecognition.stopListening();
    } else {
      resetTranscript();
      setIsEditing(false);
      SpeechRecognition.startListening({ continuous: true });
    }
  };

  const handleSend = async () => {
    if (!inputMessage.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputMessage,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    resetTranscript();
    setIsThinking(true);
    setIsEditing(false);

    try {
      // If API key is not set, use a fallback response
      // If API key is not set, use a fallback response
const API_KEY = "AIzaSyC-eiFWed8-RzTqSwTOyclYOxHr4M4gbq8";
if (!API_KEY || API_KEY === 'AIzaSyC-eiFWed8-RzTqSwTOyclYOxHr4M4gbq8') {
  // Fallback responses if API key is not set
  const fallbackResponses = [
    "I understand how you're feeling. Let's work through this together. What specific aspects of this issue are most challenging for you?",
    "Thank you for sharing that with me. It takes courage to discuss these feelings. Would you like to explore some coping strategies that might help?",
    "I hear your concerns. Many people experience similar challenges, and there are effective ways to address them. Shall we discuss some approaches that might work for you?",
    "That's important information for us to work with. Could you tell me more about how this has been affecting your daily life?"
  ];
  
  const randomIndex = Math.floor(Math.random() * fallbackResponses.length);
  const psychiatristMessage: Message = {
    id: Date.now().toString(),
    text: fallbackResponses[randomIndex],
    sender: 'psychiatrist',
    timestamp: new Date()
  };

  setMessages(prev => [...prev, psychiatristMessage]);
  setCurrentAIResponse(psychiatristMessage.text);
  speakMessage(psychiatristMessage.text);
} else {
  const response = await generateConsultation(
    doctorGender,
    messages,
    inputMessage
  );

  const psychiatristMessage: Message = {
    id: Date.now().toString(),
    text: response.message || "I understand how you're feeling. Let's work through this together.",
    sender: 'psychiatrist',
    timestamp: new Date()
  };

  setMessages(prev => [...prev, psychiatristMessage]);
  setCurrentAIResponse(psychiatristMessage.text);
  speakMessage(psychiatristMessage.text);
}
    } catch (error) {
      console.error('Error generating consultation:', error);
      const errorMessage: Message = {
        id: Date.now().toString(),
        text: "I apologize, but I'm having trouble processing that right now. Could you please rephrase or tell me more about how you're feeling?",
        sender: 'psychiatrist',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
      setCurrentAIResponse(errorMessage.text);
      speakMessage(errorMessage.text);
    } finally {
      setIsThinking(false);
    }
  };

  const handleEndChat = () => {
    setShowExportDialog(true);
  };

  const formatDate = (date: Date) => {
    return date.toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  const handleNavigation = (path: string) => {
    navigate(path);
  };
  const exportChatSummary = () => {
    const pdf = new jsPDF();
    const pageWidth = pdf.internal.pageSize.getWidth();
    const margin = 20;
    const lineHeight = 7;
    let yPosition = 20;

    pdf.setFontSize(16);
    pdf.setFont('helvetica', 'bold');
    pdf.text('Psychiatric Consultation Summary', margin, yPosition);
    yPosition += lineHeight * 2;

    pdf.setFontSize(12);
    pdf.setFont('helvetica', 'bold');
    pdf.text('Consultation History:', margin, yPosition);
    yPosition += lineHeight * 1.5;

    pdf.setFont('helvetica', 'normal');
    messages.forEach(message => {
      const sender = message.sender === 'user' ? 'You' : 'Dr. ' + (doctorGender === 'male' ? 'Vishwas' : 'Prerna');
      const timestamp = formatDate(message.timestamp);
      const text = `[${timestamp}] ${sender}: ${message.text}`;
      
      const splitText = pdf.splitTextToSize(text, pageWidth - margin * 2);
      
      if (yPosition + (splitText.length * lineHeight) > pdf.internal.pageSize.getHeight() - margin) {
        pdf.addPage();
        yPosition = margin;
      }
      
      splitText.forEach((line: string) => {
        pdf.text(line, margin, yPosition);
        yPosition += lineHeight;
      });
      
      yPosition += lineHeight / 2;
    });

    pdf.save(`psychiatric-consultation-summary.pdf`);
  };

  const handleExportDialogResponse = (shouldExport: boolean) => {
    if (shouldExport) {
      exportChatSummary();
    }
    setShowExportDialog(false);
  };

  const renderStressLevelPieChart = () => {
    const chartOptions = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'right' as const,
          labels: {
            color: 'rgba(255, 255, 255, 0.8)',
            font: {
              size: 11
            }
          }
        },
        tooltip: {
          callbacks: {
            label: function(context: any) {
              return `${context.label}: ${context.raw}%`;
            }
          }
        }
      }
    };
    
    return (
      <div className="stress-pie-chart">
        <h3><PieChart size={20} /> Stress Distribution</h3>
        <div className="chart-container">
          <Pie data={stressData} options={chartOptions} />
        </div>
        <div className="chart-note">
          <p>Data will be retrieved from MongoDB in the future</p>
        </div>
      </div>
    );
  };

  const renderCopingStrategies = () => {
    return (
      <div className="coping-strategies">
        <h3><Brain size={20} /> Coping Strategies</h3>
        <div className="strategy-bars">
          {copingStrategies.map((strategy, index) => (
            <div key={strategy.strategy} className="strategy-bar-container">
              <span className="strategy-name">{strategy.strategy}</span>
              <div className="strategy-bar-wrapper">
                <div 
                  className="strategy-bar"
                  style={{ 
                    width: `${strategy.effectiveness}%`,
                    animationDelay: `${index * 0.1}s`
                  }}
                >
                  <span className="strategy-value">{Math.round(strategy.effectiveness)}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="consultation-container">
      <div className="consultation-header">
        <div className="doctor-info">
          <div className={`doctor-avatar ${isSpeaking ? 'speaking' : ''}`}>
            <img
              src={docimgpath}
              className="avatar-animation"
              
            />
          </div>
          <div className="doctor-details">
            <h2>Psychiatric Consultation</h2>
            <p>AI-Powered Mental Health Support</p>
          </div>
        </div>
        <div className="header-controls">
          <div className="gender-selector">
            <button
              onClick={() => setDoctorGender('male')}
              className={`gender-button ${doctorGender === 'male' ? 'active' : ''}`}
            >
              Male
            </button>
            <button
              onClick={() => setDoctorGender('female')}
              className={`gender-button ${doctorGender === 'female' ? 'active' : ''}`}
            >
              Female
            </button>
          </div>
          <button onClick={handleEndChat} className="end-chat-button">
            <Home size={20} />
            End Chat
          </button>
        </div>
      </div>

      <div className="main-content">
        <div className="video-panel left">
          <div className="video-container small">
            <Webcam
              ref={webcamRef}
              audio={false}
              mirrored
              className="video-feed"
              width={280}
              height={200}
            />
            <div className="video-label">You</div>
          </div>
          {renderStressLevelPieChart()}
          {renderCopingStrategies()}
        </div>

        <div className="chat-section">
          <div className="messages-container">
            {messages.map(message => (
              <div key={message.id} className={`message ${message.sender}`}>
                <div className="message-content">
                  <p>{message.text}</p>
                  {message.sender === 'psychiatrist' && (
                    <button 
                      className="replay-voice"
                      onClick={() => speakMessage(message.text)}
                    >
                      <Volume2 size={16} />
                    </button>
                  )}
                </div>
                <span className="message-time">{formatDate(message.timestamp)}</span>
              </div>
            ))}
            {isThinking && (
              <div className="thinking-indicator">
                <div className="thinking-dots">
                  <span></span>
                  <span></span>
                  <span></span>
                </div>
                <span>Thinking...</span>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="input-container">
            <div className="input-controls">
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                placeholder={listening && !isEditing ? 'Listening...' : 'Type your message...'}
                className="message-input"
                disabled={listening && !isEditing}
              />
              {browserSupportsSpeechRecognition && (
                <button
                  onClick={toggleMic}
                  className={`mic-button ${listening ? 'active' : ''}`}
                  title={listening ? 'Stop recording' : 'Start recording'}
                >
                  {listening ? <MicOff size={20} /> : <Mic size={20} />}
                </button>
              )}
              {listening && (
                <button
                  onClick={() => setIsEditing(!isEditing)}
                  className={`edit-button ${isEditing ? 'active' : ''}`}
                  title={isEditing ? 'Submit edit' : 'Edit transcript'}
                >
                  {isEditing ? <Check size={20} /> : <Edit2 size={20} />}
                </button>
              )}
              <button
                onClick={handleSend}
                disabled={!inputMessage.trim()}
                className="send-button"
                title="Send message"
              >
                <Send size={20} />
              </button>
            </div>
            {listening && !isEditing && (
              <p className="listening-indicator">Speaking... Click edit to modify the text</p>
            )}
          </div>
        </div>

        <div className="video-panel right">
          <div className={`video-container small ${isSpeaking ? 'speaking' : ''}`}>
              <video
                ref={videoRef}
                src={doctorGender === 'male' ? maleVideoPath : femaleVideoPath}
                className="avatar-animation"
                loop
                muted
                playsInline
              />
            <div className="video-label">Dr. {doctorGender === 'male' ? 'Vishwas' : 'Prerna'}</div>
          </div>
          <div className="ai-response">
            <h3>Current Response</h3>
            <p>{currentAIResponse}</p>
          </div>
        </div>
      </div>

      {showExportDialog && (
        <div className="export-dialog-overlay">
          <div className="export-dialog">
            <h3>Save Session Summary</h3>
            <p>Would you like to save a PDF summary of this consultation?</p>
            <div className="export-dialog-buttons">
              <button onClick={() => handleExportDialogResponse(true)} className="export-yes">
                <Download size={20} />
                Yes, Save PDF
              </button>
              <button onClick={() => handleNavigation('/rehab')} className="export-no">
                No, Exit
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}